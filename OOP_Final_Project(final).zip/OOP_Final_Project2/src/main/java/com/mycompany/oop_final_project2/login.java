/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.oop_final_project2;

/**
 *
 * @author User
 */
public class login {
    String username,password;
    public login(String username){
        this.username = username;
        balance.total_balance = 999999;
        mainpage m = new mainpage();
    }
    public login(String username, String password){
        this.username = username; this.password = password;
        mainpage mp = new mainpage();
    }
}
