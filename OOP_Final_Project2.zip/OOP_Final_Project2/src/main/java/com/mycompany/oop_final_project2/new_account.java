package com.mycompany.oop_final_project2;

import java.util.HashMap;

public class new_account {
    public static HashMap<String,String> users = new HashMap<>();
    
}
