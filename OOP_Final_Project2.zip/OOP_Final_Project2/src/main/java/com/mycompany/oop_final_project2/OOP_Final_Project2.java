package com.mycompany.oop_final_project2;

public class OOP_Final_Project2 {
    
    public static void main(String[] args) {
        login_page lp = new login_page();
        
    }
    
}
